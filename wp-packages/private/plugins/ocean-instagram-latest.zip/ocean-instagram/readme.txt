=== Ocean Instagram ===
Contributors: oceanwp, freemius
Requires at least: 4.5
Tested up to: 5.2
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Display Instagram feed in a beautiful way.
This plugin requires the [OceanWP](https://oceanwp.org/) theme to be installed.

== Installation ==

1. Upload `ocean-instagram` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!

== Frequently Asked Questions ==

= I installed the plugin but it does not work =

This plugin will only work with the [OceanWP](https://oceanwp.org/) theme.

== Changelog ==

= 1.0.4 =
- Added: Russian language, thanks to Ivan Isakau.

= 1.0.3 =
- Fixed: Generated shortcode didn't show up.

= 1.0.2 =
- Added: Polish translation, thanks to Fin Fafarafiel.
- Tweak: Better approch for calling the metabox scripts.

= 1.0.1 =
- Fixed: followers and following issue.

= 1.0.0 =
- Initial release.